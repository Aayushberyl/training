class Flight < ApplicationRecord
end
