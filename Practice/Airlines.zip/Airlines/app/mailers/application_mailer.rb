class ApplicationMailer < ActionMailer::Base
  default from: 'aayush.joshi@berylsystems.com'
  layout 'mailer'
end
