require 'test_helper'

class PilotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
