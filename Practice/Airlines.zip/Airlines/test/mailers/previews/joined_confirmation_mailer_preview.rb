# Preview all emails at http://localhost:3000/rails/mailers/joined_confirmation_mailer
class JoinedConfirmationMailerPreview < ActionMailer::Preview

end
