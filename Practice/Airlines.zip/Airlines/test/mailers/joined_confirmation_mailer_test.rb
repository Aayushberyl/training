require 'test_helper'

class JoinedConfirmationMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
